java -jar packaging/target/SudokuValidator.jar $1
